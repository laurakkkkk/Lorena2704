// Simulación de API backend
const backendAPI = {
    getProducts: () => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve([
                    { id: 1, name: "Producto 1", price: 10 },
                    { id: 2, name: "Producto 2", price: 20 },
                    { id: 3, name: "Producto 3", price: 30 }
                ]);
            }, 500);
        });
    },
    addToCart: (productId) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ success: true, message: "Producto añadido al carrito" });
            }, 300);
        });
    },
    checkout: (cart) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                resolve({ success: true, orderId: Math.floor(Math.random() * 1000) });
            }, 700);
        });
    }
};

let cart = [];

async function displayProducts() {
    const content = document.getElementById('content');
    content.innerHTML = '<p>Cargando productos...</p>';
    try {
        const products = await backendAPI.getProducts();
        content.innerHTML = '';
        products.forEach(product => {
            const productDiv = document.createElement('div');
            productDiv.className = 'product';
            productDiv.innerHTML = `
                <h3>${product.name}</h3>
                <p>Precio: ${product.price}€</p>
                <button onclick="addToCart(${product.id})">Añadir al carrito</button>
            `;
            content.appendChild(productDiv);
        });
    } catch (error) {
        content.innerHTML = '<p>Error al cargar los productos.</p>';
    }
}

async function addToCart(productId) {
    try {
        const result = await backendAPI.addToCart(productId);
        if (result.success) {
            const products = await backendAPI.getProducts();
            const product = products.find(p => p.id === productId);
            cart.push(product);
            updateCart();
        }
    } catch (error) {
        console.error("Error al añadir al carrito:", error);
    }
}

function updateCart() {
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    cartItems.innerHTML = '';
    let total = 0;
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = `${item.name} - ${item.price}€`;
        cartItems.appendChild(li);
        total += item.price;
    });
    cartTotal.textContent = total;
}

async function checkout() {
    try {
        const result = await backendAPI.checkout(cart);
        if (result.success) {
            alert(`Compra finalizada. Número de orden: ${result.orderId}`);
            cart = [];
            updateCart();
        }
    } catch (error) {
        console.error("Error al finalizar la compra:", error);
    }
}

// Funciones de prueba
async function runIntegrationTests() {
    const testResults = document.getElementById('testResultsList');
    testResults.innerHTML = '';

    async function addTestResult(testName, passed) {
        const li = document.createElement('li');
        li.textContent = `${testName}: ${passed ? 'Pasó' : 'Falló'}`;
        li.style.color = passed ? 'green' : 'red';
        testResults.appendChild(li);
    }

    // Prueba 1: Cargar productos
    try {
        const products = await backendAPI.getProducts();
        addTestResult('Cargar productos', products.length > 0);
    } catch {
        addTestResult('Cargar productos', false);
    }

    // Prueba 2: Añadir al carrito
    try {
        const result = await backendAPI.addToCart(1);
        addTestResult('Añadir al carrito', result.success);
    } catch {
        addTestResult('Añadir al carrito', false);
    }

    // Prueba 3: Proceso de compra
    try {
        const result = await backendAPI.checkout([{id: 1, name: "Test Product", price: 10}]);
        addTestResult('Proceso de compra', result.success && result.orderId);
    } catch {
        addTestResult('Proceso de compra', false);
    }
}

// Event Listeners
document.getElementById('homeLink').addEventListener('click', (e) => {
    e.preventDefault();
    document.getElementById('content').innerHTML = '<h2>Bienvenido a nuestra tienda</h2>';
});

document.getElementById('productsLink').addEventListener('click', (e) => {
    e.preventDefault();
    displayProducts();
});

document.getElementById('cartLink').addEventListener('click', (e) => {
    e.preventDefault();
});

document.getElementById('checkoutBtn').addEventListener('click', checkout);

document.getElementById('runTestsLink').addEventListener('click', (e) => {
    e.preventDefault();
    runIntegrationTests();
});

// Inicializar la página
displayProducts();